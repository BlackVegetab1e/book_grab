#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "rm_service.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_pushButton_Start_clicked();

    void on_pushButton_Test_clicked();

    void on_pushButton_Close_clicked();

    void on_pushButton_move_clicked();

    void on_pushButton_gripper_clicked();

    void on_pushButton_Teach_clicked();

    void on_pushButton_state_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;

    // 手动维护句柄
    SOCKHANDLE m_sockhand = -1;

    RM_Service * m_pApi = nullptr;
};

#endif // MAINWINDOW_H
