#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDateTime>
#include <QTimer>
#include <QKeyEvent>

#ifdef __cplusplus
extern "C"
{
#endif
#include "rm_base.h"
#ifdef __cplusplus
}
#endif


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    // 连接 socket
    void on_pushButton_Start_clicked();

    // 接口测试
    void on_pushButton_Test_clicked();

    // 关闭 socket
    void on_pushButton_Close_clicked();

    //画8字测试运动接口
    void on_pushButton_move_clicked();

    //夹取物料
    void on_pushButton_gripper_clicked();

    //获取机械臂状态
    void on_pushButton_state_clicked();

    // 关节示教
    void on_pushButton_Teach_clicked();

    //透传力位混合控制补偿
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_ik_clicked();

private:
    Ui::MainWindow *ui;

    // 手动维护句柄
    SOCKHANDLE m_sockhand = -1;

    // 获取当前机械臂位姿信息
    float m_joint_state[6] = {0};

    // 错误码
    uint16_t m_arm_err[6] = {0};
    uint16_t m_sys_err[6] = {0};
protected:
};

#endif // MAINWINDOW_H
